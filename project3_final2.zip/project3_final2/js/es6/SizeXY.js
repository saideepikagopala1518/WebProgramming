class SizeXY{
  constructor (x,y){
    this.x = x;
    this.y = y;
    Object.freeze( this );
  }
}

export default SizeXY;
